---
name: Nusantara Pro
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#404848'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#707979'
  outline-variant: '#c0c8c8'
  surface-tint: '#366668'
  primary: '#002425'
  on-primary: '#ffffff'
  primary-container: '#003b3d'
  on-primary-container: '#75a5a7'
  inverse-primary: '#9ecfd1'
  secondary: '#9d4400'
  on-secondary: '#ffffff'
  secondary-container: '#ff7a21'
  on-secondary-container: '#5f2600'
  tertiary: '#231f1a'
  on-tertiary: '#ffffff'
  tertiary-container: '#39342e'
  on-tertiary-container: '#a49c94'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#baeced'
  primary-fixed-dim: '#9ecfd1'
  on-primary-fixed: '#002021'
  on-primary-fixed-variant: '#1b4e50'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb690'
  on-secondary-fixed: '#331100'
  on-secondary-fixed-variant: '#783200'
  tertiary-fixed: '#eae1d8'
  tertiary-fixed-dim: '#cec5bd'
  on-tertiary-fixed: '#1f1b16'
  on-tertiary-fixed-variant: '#4b4640'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e5e2e1'
  emerald-dark: '#003B3D'
  vibrant-orange: '#FF7A21'
  peach-surface: '#FFF5EC'
  cream-soft: '#FDFCF6'
typography:
  display-xl:
    fontFamily: Bricolage Grotesque
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Montserrat
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 120px
---

## Brand & Style

This design system establishes a "Modern Tech-Forward" identity infused with "Local Indonesian Warmth" for a premium food delivery experience. The brand personality is efficient, sophisticated, and deeply hospitable—moving away from the cluttered discount-driven aesthetics of mass-market competitors toward a curated, "Pro" level service.

The design style is a hybrid of **Minimalism** and **Glassmorphism**. It prioritizes a **Content-First** hierarchy where high-quality food photography is the hero, supported by organic, fluid shapes and translucent UI elements. The interface should feel like a premium concierge—breathable, calm, and intellectually intuitive, capturing the speed of GoFood and the vibrancy of ShopeeFood but refining them into a more polished, editorial experience.

## Colors

The palette balances the professional weight of the Indonesian culinary heritage with modern tech vibrancy. 

- **Primary (Emerald Dark):** Representing stability and premium quality, used for primary navigation and critical branding.
- **Secondary (Vibrant Orange):** Inspired by Indonesian spices and heat; used exclusively for conversion-driven actions and high-priority micro-interactions.
- **Surface (Peach/Cream):** To avoid the clinical feel of pure white, the base surface uses a soft Peach or Cream. This adds an immediate "Warmth" to the UI, making the app feel more inviting and less like a utility.
- **Functional Grays:** Low-saturation neutrals are used for secondary text and subtle borders, ensuring the chromatic brand colors remain the focal points.

## Typography

The typographic strategy uses a high-contrast pairing to differentiate the "Pro" experience. 

**Bricolage Grotesque** serves as the expressive display face. Its quirky, organic terminals and high-end geometric structure provide the "Unique Identity" required for the Indonesian market. It should be used for all major headings, price points, and merchant names.

**Montserrat** is used for all body copy and functional labels. Its global familiarity and clean, open counters ensure maximum legibility for food descriptions and delivery tracking data. 

Hierarchy is established through weight and scale; headlines should feel bold and intentional, while body text maintains a light, breathable footprint.

## Layout & Spacing

The layout is built on a **Fluid Grid** that prioritizes horizontal momentum. 

- **Mobile:** A 4-column grid with 20px side margins. Horizontal scrolling "carousels" for categories and promos should bleed into the margins to signal more content.
- **Desktop:** A 12-column centered grid with wide 120px margins to maintain an editorial, premium feel.

Spacing follows a strict 8px rhythm. Larger gaps (`lg` and `xl`) are used between different merchant types to prevent visual fatigue, while tighter spacing (`xs`) is used within "Card-less" groups to indicate relationships between food items and their prices.

## Elevation & Depth

This design system avoids heavy shadows, instead using **Glassmorphism** and **Tonal Layers** to signify depth. 

- **Surface Tiers:** Backgrounds use the `peach-surface`. Overlays, such as sticky headers or "Floating Action Buttons" (FABs), use a **Backdrop Blur (20px)** with a 70% white tint to create a glass effect.
- **Card-less Depth:** Hierarchy is created through subtle color shifts (e.g., a slightly darker cream for a container) and ultra-thin, low-opacity emerald outlines (20% opacity) rather than drop shadows.
- **Interaction Depth:** Only upon active interaction (press/hover) should a soft, diffused ambient shadow appear to provide tactile feedback.

## Shapes

The shape language is **Organic and Fluid**. While the base roundedness is 8px (`rounded-md`), the system encourages "Squircle" profiles for merchant avatars and "Pill" shapes for interactive elements.

High-impact elements like promotional banners should use asymmetrical organic radii (e.g., 40px on the top-left and bottom-right) to create a custom, "Local Warmth" feeling that breaks the rigidity of standard tech layouts.

## Components

### Buttons & FABs
Primary buttons are pill-shaped, using `vibrant-orange` for "Tambah ke Keranjang" (Add to Cart). Floating Action Buttons (FABs) are a core navigation pattern; they are elongated with a label and icon (e.g., "Lihat Pesanan") and use a backdrop-blur glass effect to remain unobtrusive over food imagery.

### Card-less Lists
Merchant and menu lists should be "Card-less." Instead of a contained box, use a clean divider line or a subtle shift in the background color. Images should have a consistent `rounded-lg` (16px) radius.

### Input Fields
Search bars and form fields should be integrated into the surface. Use the `cream-soft` color for the field background with a `primary` color border that only appears on focus. 

### Chips & Badges
Use `peach-surface` with `vibrant-orange` text for promo tags (e.g., "PROMO"). For food categories (e.g., "Pedas," "Vegetarian"), use the `primary` color at 10% opacity with solid primary text.

### Micro-interactions
Transitions between the home screen and restaurant details should use a "Shared Element" transition where the merchant image expands to become the header, creating a seamless, high-end "Pro" feel.